package com.brillio.reactivespring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactivespringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactivespringApplication.class, args);
	}

}
