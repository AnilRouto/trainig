package com.brillio.reactivespring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactivespringApplicationTests {

	@Test
	void contextLoads() {
	}

}
