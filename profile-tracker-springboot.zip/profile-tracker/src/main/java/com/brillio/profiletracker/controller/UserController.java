package com.brillio.profiletracker.controller;

import com.brillio.profiletracker.model.UserDetail;
import com.brillio.profiletracker.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/profile")
public class UserController {

    @Autowired
    private UserRepository repository;

    @GetMapping("/")
    public List<UserDetail> getAllUsers(){

        return repository.findAll();

    }
    @GetMapping("/{id}")
    public Optional<UserDetail> getByUserId(@PathVariable String id){

        return repository.findById(id);

    }
    @GetMapping("/user/{userName}")
    public UserDetail getByUserName(@PathVariable String userName){

        return repository.findByUserName(userName);

    }
    @PostMapping("/add")
    public String addUser(@RequestBody UserDetail user){

        repository.save(user);
        return "User added successfully";

    }
    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable String id){

        repository.deleteById(id);
        return "User deleted successfully";

    }
    @PutMapping("/update")
    public String updateUser(@RequestBody UserDetail user){

        repository.save(user);
        return "User updated successfully";

    }
}
