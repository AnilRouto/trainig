package com.brillio.profiletracker.repository;

import com.brillio.profiletracker.model.UserDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<UserDetail, String> {

    public UserDetail findByUserName(String userName);
}
