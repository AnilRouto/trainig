package com.brillio.profiletracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
