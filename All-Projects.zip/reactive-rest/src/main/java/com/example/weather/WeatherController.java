package com.example.weather;

import java.time.Duration;
import java.time.LocalTime;
import java.util.Random;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/weather")
public class WeatherController {

	@GetMapping(path = "/info", produces = { MediaType.TEXT_EVENT_STREAM_VALUE })
	public Flux<String> weatherInfo() {
		System.out.println("INFO =========> Inside WeatherController.weatherInfo()!!!!");
		return Flux.interval(Duration.ofMillis(700)).map(count -> convertToWeather(count));
	}

	private String convertToWeather(long tickCount) {
		Random random = new Random();
		return String.format("Tick : %s =========> Current Weather on %s is : %s<br/>", tickCount,
				LocalTime.now(), random.nextInt(40) + 5 + tickCount);
	}

}
