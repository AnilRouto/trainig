package com.example.simple;

import java.time.Duration;
import java.util.Random;

import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;

@Service
public class SimpleService {
	
	public Flux<String> generateNumbers() {
		System.out.println("INFO =========> Inside SimpleService.generateNumbers()!!!!");
		Random random = new Random();
		return Flux.range(1111,1151)
				.map(value -> String.format("Employee ID - %s and Eamployee Rank : %s</br>", value,random.nextInt(10)))
				.delayElements(Duration.ofMillis(400));
	}

	public Flux<String> greetMe(String firstName, String lastName) {
		System.out.println("INFO =========> Inside SimpleService.greetMe()!!!!");
		return Flux.just(String.format("HRU Mr, %s %s, We hope you are well!!", firstName, lastName))
				.map(value -> value.toUpperCase())
				.filter(value -> value.length() > 45)
				.delaySubscription(Duration.ofSeconds(4));
	}

}
