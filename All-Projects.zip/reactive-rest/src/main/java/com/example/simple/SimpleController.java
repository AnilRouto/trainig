package com.example.simple;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/simple")
public class SimpleController {
	
	@Autowired
	SimpleService simpleService;
	
	@GetMapping(path = "/fun", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> fun() {
		System.out.println("INFO =========> Inside SimpleController.fun()!!!!");

		Mono<String> tomato = Mono.just("Tomato<br/>");
		
		return 	Flux.just("Laptop","Mango","Apple", "Laptop","Radio", "Laptop","Phone", "Led")
					.map(value -> value+"<br/>") 
					.concatWith(tomato)
					.filter(value -> !value.startsWith("A"))
					.sort()
					.distinct()
					.zipWith(Flux.range(1, 50),(valueA,valueB) -> "Seq-"+valueB +":"+valueA)
					.delayElements(Duration.ofMillis(300)); 
	}
	
	
	@GetMapping(path = "/employee/ranks", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> employeeRanks() {
		System.out.println("INFO =========> Inside SimpleController.employeeRanks()!!!!");
		return simpleService.generateNumbers().skip(20).take(5);
	}
	
	@PostMapping(path = "/greet/v2", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = { MediaType.ALL_VALUE })
	public Flux<String> greetV2(@RequestBody Flux<Member> memberFlux) {
		System.out.println("INFO =========> Inside SimpleController.greetV2()!!!!");
		return memberFlux.flatMap(member -> simpleService.greetMe(member.getFirstName(), member.getLastName()));
	}
	
	
	@PostMapping(path = "/greet/v1", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> greetV1(@RequestBody Flux<Member> memberFlux) {
		System.out.println("INFO =========> Inside SimpleController.greetV1()!!!!");
		return Flux.just("HRU Mr. ")
				.concatWith(memberFlux.map(member -> member.getFirstName() + " "+member.getLastName()))
				.map(value -> value.toUpperCase())
				.concatWith(Mono.just(", Wish that All is Well!!"))
				.distinct()
				.take(50);
	}

	@GetMapping(path = "/love/{name}", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> love(@PathVariable("name") String name) {
		System.out.println("INFO =========> Inside SimpleController.love()!!!!");
		return Flux.just("Hello Dear ",name,"<br/>I<br/>","Hold On<br/>","Hold On<br/>","Hold On<br/>","Hold On<br/>","Love<br/>",
				"Hold On<br/>","Hold On<br/>","Hold On<br/>","You<br/>",
				"Hold On<br/>","Hold On<br/>","Hold On<br/>","Hold On<br/>","Hold On<br/>",
				"Your 200 million dollar is ready<br/>")
				.delayElements(Duration.ofMillis(700));
	}

	
	// Reactive Endpoint
	@GetMapping(path = "/welcome/v4/{name}", produces = { MediaType.TEXT_PLAIN_VALUE })
	public Mono<String> welcomeV4(@PathVariable("name") String name) {
		System.out.println("INFO =========> Inside SimpleController.welcomeV4()!!!!");

		return Mono.just(name).map(nm -> String.format("Hello Mr : %s ,Welcome to Reactive Web World!!", nm))
				.map(value -> value.toUpperCase()).delayElement(Duration.ofSeconds(3));
	}

	// Reactive Endpoint
	@GetMapping(path = "/welcome/v3/{name}", produces = { MediaType.TEXT_PLAIN_VALUE })
	public Mono<String> welcomeV3(@PathVariable("name") String name) {
		System.out.println("INFO =========> Inside SimpleController.welcomeV3()!!!!");
		// 500 LOC or 2 minutes
		/*
		 * return Mono.just("Welcome to Reactive Web World!!") .map(value ->
		 * String.format("Hello Mr : %s , %s",name,value)) .map(value ->
		 * value.toUpperCase());
		 */

		return Mono.just(name).map(nm -> String.format("Hello Mr : %s ,Welcome to Reactive Web World!!", nm))
				.map(value -> value.toUpperCase());
	}

	// Reactive Endpoint
	@GetMapping(path = "/welcome/v2", produces = { MediaType.TEXT_PLAIN_VALUE })
	public Mono<String> welcomeV2() {
		System.out.println("INFO =========> Inside SimpleController.welcomeV2()!!!!");
		// 500 LOC or 2 minutes
		return Mono.just("Welcome to Reactive Web World!!").map(value -> value.toUpperCase());
	}

	// NoN Reactive Endpoint
	@GetMapping(path = "/welcome/v1", produces = { MediaType.TEXT_PLAIN_VALUE })
	public String welcomeV1() {
		System.out.println("INFO =========> Inside SimpleController.welcomeV1()!!!!");
		return "Welcome to Reactive Web World!!";
	}

}
