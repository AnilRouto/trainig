package com.example.errors;

import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;

@Service
public class PaymentService {

	public Flux<String> payByCard(double amount, String item) {
		System.out.println("INFO =========> Inside PaymentService.payByCard()!!!!");
		return Flux.just(amount).map(value -> {
			// Simulating a Payment Failure
			if (value <= 200.00) {
				throw new PaymentFailureException("Payment cound not be processed!!");
			} else {
				return String.format("Payment of Rs/- %s done by Card for %s!!<br/>", value, item);
			}
		});
	}

	public Flux<String> payByUPI(double amount, String item) {
		System.out.println("INFO =========> Inside PaymentService.payByUPI()!!!!");
		return Flux.just(amount).map(value -> String.format("Payment of Rs/- %s done by UPI for %s!!<br/>", value, item));
	}

	public Flux<String> payByCash(double amount, String item) {
		System.out.println("INFO =========> Inside PaymentService.payByCash()!!!!");
		return Flux.just(amount).map(value -> String.format("Payment of Rs/- %s done by Cash for %s!!<br/>", value, item));
	}

}
