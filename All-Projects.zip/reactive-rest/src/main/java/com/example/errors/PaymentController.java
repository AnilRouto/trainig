package com.example.errors;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import reactor.util.retry.Retry;

@RestController
@RequestMapping("/payment")
public class PaymentController {

	@Autowired
	PaymentService paymentService;
	
	//Retry Again with a delay in each retry and after that go for Alternate Path
	@GetMapping(path = "/pay/pizza/{name}/v4", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> payForPizzaV4(@PathVariable("name") String name) {
		System.out.println("INFO =========> Inside PaymentController.payForPizzaV4()!!!!");
		double currentPayment = 180.00;
		return Flux.just(currentPayment)
				.flatMap(amount -> paymentService.payByCard(amount, name))
				.retryWhen(Retry.backoff(4, Duration.ofMillis(800))) 
				.onErrorResume(ex -> {
					System.out.println("ERROR ============> "+ex.getMessage()+ " ===========> So falling back to alternative path!!!");
					return paymentService.payByCash(currentPayment, name);
				 })
				.delayElements(Duration.ofMillis(600));
	}
	
	//Retry Again with a delay in each retry
	@GetMapping(path = "/pay/pizza/{name}/v3", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> payForPizzaV3(@PathVariable("name") String name) {
		System.out.println("INFO =========> Inside PaymentController.payForPizzaV3()!!!!");
		return Flux.just(180.00) //Simulating only one payment by one user 
				.flatMap(amount -> paymentService.payByCard(amount, name))
				//.retryWhen(Retry.fixedDelay(4, Duration.ofMillis(800))) //Do not use fixed/constant delay, no good
				.retryWhen(Retry.backoff(4, Duration.ofMillis(800))) //Use random delays, realistic
				.onErrorReturn("Payment Failed after many Tries!!<br/>")
				.delayElements(Duration.ofMillis(600));
	}

	//Retry Again with no delay
	//BAd Idea!!!
	@GetMapping(path = "/pay/pizza/{name}/v2", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> payForPizzaV2(@PathVariable("name") String name) {
		System.out.println("INFO =========> Inside PaymentController.payForPizzaV2()!!!!");
		return Flux.just(180.00) //Simulating only one payment by one user 
				.flatMap(amount -> paymentService.payByCard(amount, name))
				.retry(4)
				.onErrorReturn("Payment Failed after many Tries!!<br/>")
				.delayElements(Duration.ofMillis(600));
	}

	
	//Fallback to Alternative path in case of failure
	@GetMapping(path = "/pay/pizza/{name}/v1", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> payForPizzaV1(@PathVariable("name") String name) {
		System.out.println("INFO =========> Inside PaymentController.payForPizzaV1()!!!!");
		return Flux.just(500.00,1000.00,1200.00,3400.0,180.00,1500.00,4200.00) //Simulating 7 payments by different users
				.flatMap(amount -> paymentService.payByCard(amount, name).onErrorResume(ex -> {
					System.out.println("ERROR ============> "+ex.getMessage()+ " ===========> So falling back to alternative path!!!");
					return paymentService.payByCash(amount, name);
				}))
				.delayElements(Duration.ofMillis(600));
	}
	
}
