package com.example.errors;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/resilient")
public class ResilientController {

	@Autowired
	MathService mathService;
	
	//Better to decide first to recover from error if not possible, then return error message
	@GetMapping(path = "/divide/v4", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> divideV4() {
		System.out.println("INFO =========> Inside ResilientController.divideV4()!!!!");
		return Flux.just(5,8,12,0,2,20,10)
				.map(value -> String.format("500 / %s is %s!!<br/>",value,(500 / value)))
				.map(String::toUpperCase)
				.filter(value -> value.length() > 10)
				.onErrorReturn(ex -> ex instanceof ArithmeticException,"Divide by zero, Already Recovered!!")
				.delayElements(Duration.ofMillis(600));
	}
	
	@GetMapping(path = "/divide/v3", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> divideV3() {
		System.out.println("INFO =========> Inside ResilientController.divideV3()!!!!");
		return mathService.doDivideEfficient();
	}


	@GetMapping(path = "/divide/v2", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> divideV2() {
		System.out.println("INFO =========> Inside ResilientController.divideV2()!!!!");
		return Flux.just(5,8,12,4,2,0,10)
			.map(mathService::doDivide)
			.map(value -> String.format("Result is : %s!!",value))
			.map(String::toUpperCase)
			.onErrorReturn("Divide by zero, Already Handled!!");
	}

	@GetMapping(path = "/divide/v1", produces = { MediaType.TEXT_HTML_VALUE })
	public Flux<String> divideV1() {
		System.out.println("INFO =========> Inside ResilientController.divideV1()!!!!");
		return Flux.just(5,8,12,0,2,20,10)
			.map(value -> String.format("500 / %s is %s!!<br/>",value,(500 / value)))
			.map(String::toUpperCase)
			.filter(value -> value.length() > 10)
			.onErrorReturn("Divide by zero, Already Handled!!");
	}
}
