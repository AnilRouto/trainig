package com.example.errors;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;

@Service
public class MathService {

	// NoN Blocking Code
	// Good!!!!
	public Flux<String> doDivideEfficient() {
		System.out.println("INFO =========> Inside MathService.doDivideEfficient()!!!!");
		return Flux.just(5,8,12,0,2,20,10)
				.map(value -> String.format("500 / %s is %s!!<br/>",value,(500 / value)))
				.map(String::toUpperCase)
				.filter(value -> value.length() > 10)
				.onErrorReturn("Divide by zero, Already Handled!!")
				.delayElements(Duration.ofMillis(800));
	}

	// Blocking Code
	// Bad!!!!
	public int doDivide(int value) {
		System.out.println("INFO =========> Inside MathService.doDivide()!!!!");
		try {
			TimeUnit.SECONDS.sleep(4);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return 500 / value;
	}

}
