package com.example.errors;

public class PaymentFailureException extends RuntimeException {

	public PaymentFailureException() {
	}

	public PaymentFailureException(String message) {
		super(message);
	}
}
