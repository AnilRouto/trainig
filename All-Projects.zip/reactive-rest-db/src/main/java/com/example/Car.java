package com.example;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Cars")
public class Car {
	
	@Id
	int vin;
	
	String model;
	String make;
	double price;
	String color;
	
	public Car() {
	}
	
	public Car(String model, String make, double price, String color) {
		this.model = model;
		this.make = make;
		this.price = price;
		this.color = color;
	}
	
	public Car(int vin, String model, String make, double price, String color) {
		this.vin = vin;
		this.model = model;
		this.make = make;
		this.price = price;
		this.color = color;
	}
	public int getVin() {
		return vin;
	}
	public void setVin(int vin) {
		this.vin = vin;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	@Override
	public String toString() {
		return "Car [vin=" + vin + ", model=" + model + ", make=" + make + ", price=" + price + ", color=" + color
				+ "]";
	}

	
	
	
}
