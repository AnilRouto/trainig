package com.example;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractReactiveMongoConfiguration;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableReactiveMongoRepositories;

import com.mongodb.reactivestreams.client.MongoClients;

@Configuration
@EnableReactiveMongoRepositories (basePackages = "com.example")
public class MongoDBConfiguration extends AbstractReactiveMongoConfiguration {

	@Value("${db.port}")
	String databasePort;

	@Value("${db.name}")
	String databaseName;

	@Override
	protected String getDatabaseName() {
		return databaseName;
	}

	@Bean
	protected ReactiveMongoTemplate createReactiveMongoTemplate() {
		return new ReactiveMongoTemplate(MongoClients.create(), getDatabaseName());
	}

}
