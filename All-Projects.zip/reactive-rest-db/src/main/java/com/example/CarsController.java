package com.example;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")
public class CarsController {
	
	@Autowired
	CarsDAO carsDAO;
	
	
	//Delete a Car
	@DeleteMapping(path = "/cars/{vin}")
	@ResponseStatus(HttpStatus.OK)
	public void deleteCar(@PathVariable("vin") int vin) {
		System.out.println("INFO =========> Inside CarsController.deleteCar()!!!!");
		carsDAO.deleteById(vin).subscribe();
	}
	
	//Update a Car
	@PutMapping(path = "/cars", consumes = { MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(HttpStatus.OK)
	public Mono<Car> updateCar(@RequestBody Car car) {
		System.out.println("INFO =========> Inside CarsController.updateCar()!!!!");
		return carsDAO.save(car);
	}
	
	//Read Car by VIN
	@GetMapping(path = "/cars/{vin}", produces = { MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Mono<Car>> getCarsByVIN(@PathVariable("vin") int vin) {
		System.out.println("INFO =========> Inside CarsController.getCarsByVIN()!!!!");
		Mono<Car> monoOriginal = carsDAO.findById(vin);
		return new ResponseEntity<Mono<Car>>(monoOriginal, monoOriginal == null ? HttpStatus.NOT_FOUND : HttpStatus.OK); 
	}

	//Read All Cars
	@GetMapping(path = "/cars", produces = { MediaType.TEXT_EVENT_STREAM_VALUE})
	public Flux<Car> getAllCars() {
		System.out.println("INFO =========> Inside CarsController.getAllCars()!!!!");
		return carsDAO.findAll().delayElements(Duration.ofMillis(500));
	}

	//Create a New Car
	@PostMapping(path = "/cars", consumes = { MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(HttpStatus.CREATED)
	public void createCar(@RequestBody Car car) {
		System.out.println("INFO =========> Inside CarsController.createCar()!!!!");
		//Trigger the stream by invoking this terminal operation 
		carsDAO.save(car).subscribe();
	}

	
}
