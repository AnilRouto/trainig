package com.example.exercise;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class WeatherService {

	List<WeatherListener> listeners = new ArrayList<>();
	ExecutorService executorService = Executors.newCachedThreadPool();
	Random random = new Random(10);
	
	public WeatherService() {
		//Start generating data in the stream
		changeCurrentWeather();
	}

	public void generateWeather(String city, int minInitial, int maxInitial) {
		executorService.execute(() -> {
			while (true) {
				int currentMin = minInitial + random.nextInt();
				int currentMax = maxInitial + random.nextInt();
				WeatherInfo weatherInfo = new WeatherInfo(city,currentMin,currentMax);
				listeners.forEach((listener) -> {
					listener.onWeatherChange(weatherInfo);
				});
				
				try {
					//Simulating some delay for each weather change
					TimeUnit.MILLISECONDS.sleep((int)((Math.random() * 500) + 400));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
	}

	String[] cityArray = { "Pune", "Delhi", "Mumbai" };
	int[] cityMinTemp = { 12, 24, 26 };
	int[] cityMaxTemp = { 25, 45, 35 };

	public void changeCurrentWeather() {
		for (int idx = 0; idx < cityArray.length; idx++) {
			generateWeather(cityArray[idx], cityMinTemp[idx], cityMaxTemp[idx]);
		}
	}

	public void addListener(WeatherListener weatherListener) {
		listeners.add(weatherListener);
	}
}
