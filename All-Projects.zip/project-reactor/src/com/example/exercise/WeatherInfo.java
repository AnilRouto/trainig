package com.example.exercise;

public class WeatherInfo {

	String city;
	int min;
	int max;

	public WeatherInfo(String city, int min, int max) {
		this.city = city;
		this.min = min;
		this.max = max;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	@Override
	public String toString() {
		return "WeatherInfo [city=" + city + ", min=" + min + ", max=" + max + "]";
	}

}
