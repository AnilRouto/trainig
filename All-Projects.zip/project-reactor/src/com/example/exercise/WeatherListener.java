package com.example.exercise;

public abstract class WeatherListener {
	
	public abstract void onWeatherChange(WeatherInfo weatherInfo);
	
}
