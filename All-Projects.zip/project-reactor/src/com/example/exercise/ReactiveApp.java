package com.example.exercise;

import java.time.LocalTime;
import java.util.concurrent.TimeUnit;

import reactor.core.publisher.ConnectableFlux;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;

public class ReactiveApp {

	public static void main(String[] args) {
		
		WeatherService weatherService = new WeatherService();

		// Cold Publisher
		Flux<WeatherInfo> reactivePublisher = Flux.create((emitter) -> {

			WeatherListener weatherListenerA = new WeatherListener() {

				@Override
				public void onWeatherChange(WeatherInfo weatherInfo) {
					//Reading data/event from non reactive listener
					//Writing same data/event into reactive stream
					System.out.println("Listener A got live info and pumped into live reactive stream!!!");
					weatherInfo.setCity("Listener A ---> "+weatherInfo.getCity().toUpperCase());
					emitter.next(weatherInfo);
				}
			};
			
			WeatherListener weatherListenerB = new WeatherListener() {

				@Override
				public void onWeatherChange(WeatherInfo weatherInfo) {
					//Reading data/event from non reactive listener
					//Writing same data/event into reactive stream
					weatherInfo.setCity("Listener B ---> "+weatherInfo.getCity().toLowerCase());
					System.out.println("Listener B got live info and pumped into live reactive stream!!!");
					emitter.next(weatherInfo);
				}
			};

			weatherService.addListener(weatherListenerA);
			weatherService.addListener(weatherListenerB);
			
		}, FluxSink.OverflowStrategy.BUFFER);

		// Hot Publisher
		ConnectableFlux<WeatherInfo> publisher = reactivePublisher.publish();

		publisher.subscribe(weatherInfo -> {
			System.out.printf("%s ====> Min : %s and Max: %s on : %s%n", weatherInfo.getCity(), weatherInfo.getMin(),
					weatherInfo.getMax(), LocalTime.now());
		});
		
		publisher.subscribe(weatherInfo -> {
			System.out.printf("%s ====> Max: %s on : %s%n", weatherInfo.getCity(), weatherInfo.getMax(), LocalTime.now());
		});
		
		//Start Hot Publisher to publish data
		publisher.connect();
		
		try {
			TimeUnit.MINUTES.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	
		System.out.println("Done!!!!");
	}

}
