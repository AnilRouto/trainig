package com.example;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class Main {

	public static void main(String[] args) {
		// UC1();
		// UC2();
		// UC3();
		// UC4();
		// UC5();
		// UC6();
		// UC7();
		// UC8();
		// UC9();
		// UC10();
		// UC11();
		// UC12();
		UC13();

	}

	private static void UC13() {
		try {
			Flux<String> publisher = Flux.just(5, 8, 12, 4, 0, 20, 10)
					.map(value -> String.format("500 / %s is %s!!<br/>", value, (500 / value)));
			publisher.subscribe(System.out::println);
		} catch (ArithmeticException exception) {
			exception.printStackTrace();
		}
	}

	private static void UC12() {

		Mono<String> publisherA = Mono.just("Hello Mr Shyam, I will give you 100 million dollar")
				.delaySubscription(Duration.ofMillis(800)); // Delaying stream start by 800 ms

		Flux<String> publisherB = Flux
				.just("Hello", "Mr", "Bill", "Gates", "Wait", "I", "have", "200", "million", "dollars", "for", "you")
				.delayElements(Duration.ofMillis(1000)); // Delaying each element by 600 ms

		Flux<String> publisherC = Flux
				.just("Hello", "Mr", "Ram", "Singh", "Wait", "I", "have", "600", "million", "dollars", "for", "you")
				.delayElements(Duration.ofMillis(600)); // Delaying each element by 600 ms

		// Will choose the winner and will return a new stream
		Flux.first(publisherA, publisherB, publisherC).toIterable().forEach(System.out::println);

		System.out.println("Finished Work!!!!!!");
	}

	// Main thread will exit before reactive threads so make main thread stays for
	// some
	// time to keep JVM running and giving opportunity to finish task
	// asynchronously to background workers
	private static void UC11() {

		Mono<String> tomato = Mono.just("Tomato");

		Flux<String> publisher = Flux.just("Laptop", "Mango", "Apple", "Laptop", "Radio", "Laptop", "Phone", "Led")
				.map(value -> value.toUpperCase()) // Non Blocking
				.concatWith(tomato) // Non Blocking
				.flatMap(value -> Flux.fromArray(value.split(""))) // Non Blocking
				.filter(value -> !value.startsWith("A")) // Non Blocking
				.sort() // Non Blocking
				.distinct() // Non Blocking
				.zipWith(Flux.range(1, 50), (valueA, valueB) -> "Seq-" + valueB + ":" + valueA) // Non Blocking
				.delayElements(Duration.ofMillis(600)); // Delaying each element by 600 ms

		// Converting non blocking code to blocking code
		// Welcome back to old not reactive world
		publisher.toIterable().forEach(System.out::println);

		System.out.println("Finished Work!!!!!!");
	}

	// Main thread will exit before reactive threads so make main thread stays for
	// some
	// time to keep JVM running and by converting from non blocking to blocking code
	// But not a good idea
	private static void UC10() {

		Mono<String> tomato = Mono.just("Tomato");

		Flux<String> publisher = Flux.just("Laptop", "Mango", "Apple", "Laptop", "Radio", "Laptop", "Phone", "Led")
				.map(value -> value.toUpperCase()) // Non Blocking
				.concatWith(tomato) // Non Blocking
				.flatMap(value -> Flux.fromArray(value.split(""))) // Non Blocking
				.filter(value -> !value.startsWith("A")) // Non Blocking
				.sort() // Non Blocking
				.distinct() // Non Blocking
				.zipWith(Flux.range(1, 50), (valueA, valueB) -> "Seq-" + valueB + ":" + valueA) // Non Blocking
				.delaySubscription(Duration.ofSeconds(2)); // Delay the start of the stream

		// Converting non blocking code to blocking code
		// Welcome back to old not reactive world
		publisher.toIterable().forEach(System.out::println);

		System.out.println("Finished Work!!!!!!");
	}

	// Main thread will exit before reactive threads so make main thread stays for
	// some
	// time to keep JVM running and giving opportunity to finish task
	// asynchronously to background workers
	private static void UC9() {

		Mono<String> tomato = Mono.just("Tomato");

		Flux<String> publisher = Flux.just("Laptop", "Mango", "Apple", "Laptop", "Radio", "Laptop", "Phone", "Led")
				.map(value -> value.toUpperCase()) // Non Blocking
				.concatWith(tomato) // Non Blocking
				.flatMap(value -> Flux.fromArray(value.split(""))) // Non Blocking
				.filter(value -> !value.startsWith("A")) // Non Blocking
				.sort() // Non Blocking
				.distinct() // Non Blocking
				.zipWith(Flux.range(1, 50), (valueA, valueB) -> "Seq-" + valueB + ":" + valueA) // Non Blocking
				.delaySubscription(Duration.ofSeconds(2)); // Delay the start of the stream

		publisher.subscribe(System.out::println);

		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("Finished Work!!!!!!");
	}

	// Reactive streams having data analysis capabilities
	// Mix two streams together
	// Adding more data on the way while streaming is going on
	private static void UC8() {

		Mono<String> tomato = Mono.just("Tomato");

		// Transformed Flux/Rective Streams
		// NoN Blocking
		Flux<String> publisher = Flux.just("Laptop", "Mango", "Apple", "Laptop", "Radio", "Laptop", "Phone", "Led")
				.map(value -> value.toUpperCase()).concatWith(tomato).flatMap(value -> Flux.fromArray(value.split("")))
				.filter(value -> !value.startsWith("A")).sort().distinct()
				.zipWith(Flux.range(1, 50), (valueA, valueB) -> "Seq-" + valueB + ":" + valueA);

		publisher.subscribe(System.out::println);
	}

	// Reactive streams having data analysis capabilities
	// Mix two streams together
	private static void UC7() {

		// Transformed Flux/Rective Streams
		// NoN Blocking
		Flux<String> dataPublisher = Flux.just("Laptop", "Mango", "Apple", "Laptop", "Radio", "Laptop", "Phone", "Led")
				.map(value -> value.toUpperCase()).flatMap(value -> Flux.fromArray(value.split("")))
				.filter(value -> !value.startsWith("A")).sort();
		// .distinct();
		// .skip(4);
		// .take(2);

		Flux<Integer> sequencePublisher = Flux.range(1, 50);

		Flux<String> publisher = dataPublisher.zipWith(sequencePublisher,
				(valueA, valueB) -> "Seq-" + valueB + ":" + valueA);

		// dataPublisher.subscribe(System.out::println);
		// sequencePublisher.subscribe(System.out::println);

		publisher.subscribe(System.out::println);
	}

	// Reactive streams having data analysis capabilities
	private static void UC6() {

		// Transformed Flux/Rective Streams
		// NoN Blocking
		Flux<String> publisher = Flux.just("Laptop", "Mango", "Apple", "Laptop", "Radio", "Laptop", "Phone", "Led")
				.map(value -> value.toUpperCase()).flatMap(value -> Flux.fromArray(value.split("")))
				.filter(value -> !value.startsWith("A")).sort().distinct().skip(4).take(2);

		publisher.subscribe(System.out::println);
	}

	// Infinite Publisher emitting unlimited events/data/messages continously but
	// converted to finit one
	private static void UC5() {

		/*
		 * Flux<Integer> publisherInfinite = Flux.generate((sink) -> { Random random =
		 * new Random(); sink.next(random.nextInt(5555)); });
		 * 
		 * Flux<Integer> publisherFinite = publisherInfinite.take(20);
		 * publisherFinite.subscribe(System.out::println);
		 */

		Flux<Object> publisher = Flux.generate((sink) -> {
			Random random = new Random();
			sink.next(random.nextInt(5555));
		}).take(20);

		publisher.subscribe(System.out::println);
	}

	// Infinite Publisher emitting unlimited events/data/messages continously
	private static void UC4() {

		Flux<Integer> publisher = Flux.generate((sink) -> {
			Random random = new Random();
			sink.next(random.nextInt(5555));
		});

		publisher.subscribe(System.out::println);
	}

	// Publisher emitting many events/data/messages and different in memory data
	// sources
	private static void UC3() {

		// array data source for reactive stream/flux
		Integer[] numbers = new Integer[] { 34, 45, 1, 22, 34, 65, 78, 98, 77, 11, 33, 44 };

		// array data source for reactive stream/flux
		List<Integer> list = Arrays.asList(10, 20, 54, 23, 45);

		// Convert from blocking code to non blocking code
		Flux<Integer> publisher = Flux.fromArray(numbers);
		publisher.subscribe(System.out::println);

		System.out.println("=====================================");

		publisher = Flux.fromIterable(list);
		publisher.subscribe(System.out::println);

	}

	// Publisher emitting many events/data/messages
	private static void UC2() {

		// Create a reactive publisher
		Flux<String> publisher = Flux.just("Laptop", "Radio", "Phone", "Led"); // data source is static

		// Create a reactive subscriber and attach to publisher so that data flow can
		// start
		publisher.subscribe((data) -> System.out.println(data));
		publisher.subscribe(Main::dataSubscriber);
	}

	// Publisher emitting only one event/data/message
	private static void UC1() {
		// Create a reactive publisher
		Mono<String> publisher = Mono.just("Laptop");

		// Create a reactive subscriber and attach to publisher so that data flow can
		// start
		publisher.subscribe((data) -> System.out.println(data));
		publisher.subscribe(Main::dataSubscriber);
	}

	private static void dataSubscriber(String data) {
		System.out.printf("Received Element : %s%n", data);
	}
}
