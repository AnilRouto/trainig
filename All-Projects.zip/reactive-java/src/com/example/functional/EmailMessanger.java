package com.example.functional;

public class EmailMessanger implements Messanger {
	
	@Override
	public void send() {
		System.out.println("Email Sent!!!!");
	}
}

