package com.example.functional;

/*
 * Author - Ritesh Tyagi 
 * Version - 1.2.0
 * Since - 18-Jun-2019
 */
@FunctionalInterface
public interface Messanger {
	void send();
}

