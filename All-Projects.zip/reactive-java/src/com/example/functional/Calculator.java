package com.example.functional;

public interface Calculator {
	void doCal(int arg1,int arg2);
}

