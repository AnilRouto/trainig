package com.example.functional;


public class MessangerApp {

	public static void main(String[] args) {
		UC1();
		UC2();
		UC3();
	}

	// Java 8
	// Lambda implementation of functional interface
	private static void UC3() {
		Messanger messanger = () -> {
			System.out.println("WhatsApp Sent!!!!");
		};

		messanger.send();
		System.out.println(messanger);
		System.out.println(messanger.getClass());
	}

	// Before Java 8
	// Unnamed/Anonymous class implementation of functional interface
	private static void UC2() {
		Messanger messanger = new Messanger() {

			@Override
			public void send() {
				System.out.println("SMS Sent!!!!");
			}
		};
		messanger.send();
		System.out.println(messanger);
		System.out.println(messanger.getClass());
	}

	// Before Java 8
	// Concrete class named implementation of functional interface
	private static void UC1() {
		Messanger messanger = new EmailMessanger();
		messanger.send();
		System.out.println(messanger);
		System.out.println(messanger.getClass());
	}
}
