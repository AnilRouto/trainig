package com.example.functional;

public class CalculatorImpl implements Calculator {
	
	@Override
	public void doCal(int arg1, int arg2) {
		System.out.printf("Result : %s%n",(arg1+arg2));
	}
}

