package com.example.functional;

public class CalculatorApp {

	public static void main(String[] args) {
		UC1();
		UC2();
		UC3();
	}

	// Java 8
	// Lambda implementation of functional interface
	private static void UC3() {
		Calculator calculator = (int arg1, int arg2) -> {
			System.out.printf("Result : %s%n", (arg1 * arg2));
		};

		calculator.doCal(10, 2);
	}

	// Before Java 8
	// Unnamed/Anonymous class implementation of functional interface
	private static void UC2() {
		Calculator calculator = new Calculator() {

			@Override
			public void doCal(int arg1, int arg2) {
				System.out.printf("Result : %s%n", (arg1 - arg2));
			}
		};
		calculator.doCal(10, 2);
	}

	// Before Java 8
	// Concrete class named implementation of functional interface
	private static void UC1() {
		Calculator calculator = new CalculatorImpl();
		calculator.doCal(10, 2);
	}
}
