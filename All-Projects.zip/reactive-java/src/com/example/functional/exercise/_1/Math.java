package com.example.functional.exercise._1;

public interface Math {
	void calculate(int arg1,int arg2);
}

