package com.example.functional.exercise._1;

/*
 * Developer - Ritesh Tyagi
 * Role - Application Developer
 * Date - 31-Aug-2021
 */
//Application Developer using API build and designed by other developer 
public class MathApp {

	public static void main(String[] args) {
		// UC1();
		// UC2();
		UC3();
	}

	// Java 8
	// No Need to pass concrete or anonymous class implementation to method argument
	// Simple pass inline functions using lambda
	private static void UC3() {
		MathService mathService = new MathService();

		// Inline functional programming
		mathService.doCalculate((int arg1, int arg2) -> {
			System.out.printf("SUM : %s%n", (arg1 + arg2));
		});

		mathService.doCalculate((int arg1, int arg2) -> System.out.printf("SUM : %s%n", (arg1 + arg2)));

		mathService.doCalculate((arg1, arg2) -> System.out.printf("SUM : %s%n", (arg1 + arg2)));

		mathService.doCalculate((arg1, arg2) -> System.out.printf("DIFF : %s%n", (arg1 - arg2)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("MULTIPLY : %s%n", (arg1 * arg2)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("DIVIDE : %s%n", (arg1 / arg2)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("RESULT : %s%n", (arg1 + arg2 + 100)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("RESULT : %s%n", (arg1 + arg1 + arg2)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("RESULT : %s%n", (arg1 + arg2 + arg2)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("RESULT : %s%n", (arg1 + arg1 + arg2 + arg2)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("RESULT : %s%n", (arg1 * 2 + arg2 * 2)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("RESULT : %s%n", (arg1 / 10 + arg2 / 10)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("RESULT : %s%n", (arg1 - 2 + arg2)));
		mathService.doCalculate((arg1, arg2) -> System.out.printf("RESULT : %s%n", (arg1 - 6 + arg2 * 7)));

		mathService.doCalculate(100,20,(arg1, arg2) -> System.out.printf("RESULT : %s%n", (arg1 + arg2)));

	}

	// Java 8
	// No Need to pass concrete or anonymous class implementation to method argument
	// Simple pass inline functions using lambda
	private static void UC2() {
		MathService mathService = new MathService();
		Math mathImpl = (int arg1, int arg2) -> {
			System.out.printf("SUM : %s%n", (arg1 + arg2));
		};

		// Inline functional programming
		mathService.doCalculate(mathImpl);
	}

	// Before Java 8
	// Need to pass concrete or anonymous class implementation to method argument
	private static void UC1() {
		MathService mathService = new MathService();
		mathService.doCalculate(new Math() {

			@Override
			public void calculate(int arg1, int arg2) {
				System.out.printf("SUM : %s%n", (arg1 + arg2));
			}
		});
	}
}
