package com.example.functional.exercise._1;

/*
 * Developer - John
 * Role - API Designer
 * Date - 12-Aug-2020
 */
//This reusable API allows to do simple calculations of two integer numbers 
public class MathService {
	
	public void doCalculate(Math math) {
		System.out.println("Loading configurations!!");
		System.out.println("Doing Internal Calculations!!");
		//20 LOC
		math.calculate(10, 5);
		System.out.println("Calculation Done!!");
	}
	
	public void doCalculate(int i,int j,Math math) {
		System.out.println("Loading configurations!!");
		System.out.println("Doing Internal Calculations!!");
		//20 LOC
		math.calculate(i,j);
		System.out.println("Calculation Done!!");
	}
	
}

