package com.example.functional.exercise._4;

public class StringsUtil {

	public static void show(String value) {
		// 20 LOC
		System.out.printf("Value is : %s%n", value);
	}

	public static void convertAndShow(String value) {
		// 20 LOC
		System.out.printf("Converted Value is : %s%n", value.toUpperCase());
	}

	public void reverseAndShow(String value) {
		// 20 LOC
		char[] array = value.toCharArray();
		for (int i = array.length - 1; i >= 0; i--) {
			System.out.print(array[i]);
		}
		System.out.println();
	}
}
