package com.example.functional.exercise._4;

/*
 * Developer - Ritesh Tyagi
 * Role - Application Developer
 * Date - 31-Aug-2021
 */
//Application Developer using API built and designed by other developer 
public class DataListApp {

	public static void main(String[] args) {
		new DataListApp();
	}
	
	public DataListApp() {
		DataList dataList = new DataList();
		dataList.iterate(value -> System.out.printf("Name : %s%n",value));
		System.out.println("================================================");
		dataList.iterate(this::display);
		System.out.println("================================================");
		dataList.iterate(StringsUtil::show);
		System.out.println("================================================");
		dataList.iterate(StringsUtil::convertAndShow);
		System.out.println("================================================");
		StringsUtil util = new StringsUtil();
		System.out.println("Reversed Value!!");
		dataList.iterate(util::reverseAndShow);
		System.out.println("================================================");
		dataList.iterate(System.out::println);
	
	}
	
	//An old existing standard method
	public void display(String value) {
		//50 LOC
		System.out.printf("Value is : %s%n",value);
	}
	
}
