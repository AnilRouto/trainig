package com.example.functional.exercise._4;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/*
 * Developer - John
 * Role - API Designer
 * Date - 12-Aug-2020
 */
//This reusable API allows to internal iterations and playing with data
public class DataList {

	List<String> names = Arrays.asList("Mohan", "Ram", "Sohan", "Chandni", "Soni", "Jaggu", "Ghanshu");

	public void iterate(Consumer<String> consumer) {
		System.out.println("Loading configurations!!");
		System.out.println("Loading data from DB!!");
		System.out.println("Data is ready!!");
		for (String name : names) {
			consumer.accept(name);
		}
		System.out.println("Finished Iteration!!");
	}

}
