package com.example.functional.exercise._2;

import java.util.Arrays;
import java.util.List;

import java.util.function.Predicate;

/*
 * Developer - John
 * Role - API Designer
 * Date - 12-Aug-2020
 */
//This reusable API allows to internal iterations with extra filtering behaviour at run time
public class DataService {

	List<String> names = Arrays.asList("Mohan","Ram","Sohan","Chandni","Soni","Jaggu","Ghanshu");

	public void doFilter(Predicate<String> predicate) {
		System.out.println("Loading configurations!!");
		System.out.println("Loading data from DB!!");
		System.out.println("Data is ready!!");
		for(String name : names) {
			if(predicate.test(name))
				System.out.printf("Name : %s%n",name);
		}
		System.out.println("Finish!!");
	}
	
	/*public void doFilter(AppPredicate predicate) {
		System.out.println("Loading configurations!!");
		System.out.println("Loading data from DB!!");
		System.out.println("Data is ready!!");
		for(String name : names) {
			if(predicate.filter(name))
				System.out.printf("Name : %s%n",name);
		}
		System.out.println("Finish!!");
	}*/
	
}

