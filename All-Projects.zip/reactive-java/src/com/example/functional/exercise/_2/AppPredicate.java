package com.example.functional.exercise._2;

public interface AppPredicate {
	boolean filter(String value);
}

