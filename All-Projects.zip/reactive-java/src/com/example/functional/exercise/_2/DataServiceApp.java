package com.example.functional.exercise._2;

/*
 * Developer - Ritesh Tyagi
 * Role - Application Developer
 * Date - 31-Aug-2021
 */
//Application Developer using API build and designed by other developer 
public class DataServiceApp {

	public static void main(String[] args) {
	
		DataService dataService = new DataService();
		dataService.doFilter((value) -> true);
		dataService.doFilter((value) -> value.length() > 4);
		dataService.doFilter((value) -> value.length() >= 6);
		dataService.doFilter((value) -> value.startsWith("M"));
		dataService.doFilter((value) -> value.contains("o"));
		dataService.doFilter((value) -> value.contains("o") && value.length() > 4);
	}
}
