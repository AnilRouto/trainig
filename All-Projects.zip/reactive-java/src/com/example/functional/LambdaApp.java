package com.example.functional;

import java.util.Random;

public class LambdaApp {

	public static void main(String[] args) {
		// UC1();
		//UC2();
		UC3();
	}
	
	interface Function3 {
		long doWork(int seed);
	}

	private static void UC3() {
		Function3 function3 = (seed) -> {
			System.out.println("Generating long sequence....");
			Random random = new Random();	
			return random.nextInt(seed);
		};
		
		long rs = function3.doWork(5555);
		System.out.printf("Generated Value : %s%n",rs);
		
		//function3 = (seed) -> { return new Random().nextInt(seed); };
		//function3 = (seed) -> new Random().nextInt(seed);
		function3 = seed -> new Random().nextInt(seed);
	
		rs = function3.doWork(9999);
		System.out.printf("Generated Value : %s%n",rs);
		
	}


	interface Function2 {
		void doWork(int size);
	}

	private static void UC2() {
		Function2 function2 = (int size) -> System.out.printf("Doing Work of size : %s%n", size);
		function2.doWork(100);

		function2 = (size) -> System.out.printf("Doing Work of size : %s%n", size);
		function2.doWork(200);

		function2 = size -> System.out.printf("Doing Work of size : %s%n", size);
		function2.doWork(300);
	}

	interface Function1 {
		void doWork();
	}

	private static void UC1() {
		Function1 function1 = () -> {
			System.out.println("Doing Work......");
		};

		function1.doWork();

		// function1 = () -> { System.out.println("Doing more Work......"); };
		function1 = () -> System.out.println("Doing more Work......");
		function1.doWork();
	}
}
