package com.example.functional;

import java.util.List;

/*
 * Author - Ritesh Tyagi 
 * Version - 1.2.0
 * Since - 18-Jun-2019
 */
@FunctionalInterface
public interface Configuration {
	boolean configure(String system,String module,String part,List<String> options);
}

