package com.example.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamsApp {

	public static void main(String[] args) {

		// List<Integer> result =
		// doubleTheValues(Arrays.asList(12,4,23,76,54,34,90,8,6,4,12,33,66,89,34));
		// System.out.println(result);
		// UC2();
		// UC3();
		// UC4();
		// UC5();
		//UC6();
		UC7();
	}

	private static void UC7() {
			
		double result = IntStream.rangeClosed(101, 200).average().getAsDouble();
		System.out.printf("Average : %s%n",result);
		
		int rs = IntStream.rangeClosed(101, 200).min().getAsInt();
		System.out.printf("Min : %s%n",rs);

		rs = IntStream.rangeClosed(101, 200).max().getAsInt();
		System.out.printf("Max : %s%n",rs);
		
		long count = IntStream.rangeClosed(101, 200).count();
		System.out.printf("Count : %s%n",count);
		
		rs = IntStream.rangeClosed(101, 200).sum();
		System.out.printf("Sum : %s%n",rs);
		
		rs = IntStream.rangeClosed(1, Integer.MAX_VALUE).limit(200).skip(10)
				.filter(value -> value % 5 == 0)
				.sum();
		System.out.printf("Sum : %s%n",rs);
		
		
	}
	
	private static void UC6() {

		IntStream.rangeClosed(101, 200)
				.mapToObj(number -> new Car(number, "Car-" + number, (int) (Math.random() * 10)))
				.filter((car) -> car.getRank() > 5)
				.map((car) -> {
					car.setName(car.getName().toUpperCase());
					return car;
				})
				.distinct()
				.skip(5)
				.takeWhile(car -> car.getName().length() >= 4)
				.forEach(System.out::println);
	}

	private static void UC5() {

		// IntStream intStream = IntStream.of(10);
		// IntStream intStream = IntStream.of(10,20,30,40);
		// IntStream intStream = IntStream.range(10,40);
		IntStream intStream = IntStream.rangeClosed(10, 40);
		intStream.forEach(System.out::println);
	}

	// Mapper and Reducer Demo
	// Java 8
	private static void UC4() {

		List<Double> numbers = Arrays.asList(12000.00, 44000.00, 72000.00, 42000.00, 16000.00);

		/*
		 * Stream<Double> streamA = numbers.stream(); Stream<Double> streamB =
		 * streamA.map((salary) -> salary + (salary * 0.30)); Optional<Double> result =
		 * streamB.reduce((accumulator,value) -> accumulator + value);
		 * System.out.printf("Total Salary to be Paid now is : %s%n",result.get());
		 */

		Double result = numbers.stream().map((salary) -> salary + (salary * 0.30))
				.reduce((accumulator, value) -> accumulator + value).get();

		System.out.printf("Total Salary to be Paid now is : %s%n", result);

	}

	// Reducer Demo
	// Java 8
	private static void UC3() {

		List<Integer> numbers = Arrays.asList(12, 4, 23, 76, 54, 34, 90, 8, 6, 4, 12, 33, 66, 89, 34);

		Stream<Integer> streamA = numbers.stream();

		Optional<Integer> result = streamA.reduce((accumulator, value) -> accumulator + value);

		System.out.printf("Final Result : %s%n", result.get());

	}

	// Mapper Demo
	// Java 8
	private static void UC2() {
		// Data Source for streaming/data pipeline
		// In Memory Data Source
		List<Integer> numbers = Arrays.asList(12, 4, 23, 76, 54, 34, 90, 8, 6, 4, 12, 33, 66, 89, 34);

		Stream<Integer> streamA = numbers.stream();

		Stream<Integer> streamB = streamA.map(value -> {
			System.out.printf("Inside Mapper and doubling value!!!%n");
			return value * 2;
		});

		Stream<Integer> streamC = streamB.map(value -> {
			System.out.printf("Inside Mapper and increasing by 5%n");
			return value * 5;
		});

		streamC.forEach(value -> System.out.printf("Final Value : %s%n", value));
	}

	// Mapper Demo
	// Before Java 8
	private static List<Integer> doubleTheValues(List<Integer> numbers) {
		System.out.println(numbers);
		// Temporary intermediate collection in memory
		// Total memory wastage
		List<Integer> doubleNumbers = new ArrayList<>();

		// Internal iteration
		for (Integer value : numbers) {
			doubleNumbers.add(value * 2);
		}
		return doubleNumbers;
	}

}
