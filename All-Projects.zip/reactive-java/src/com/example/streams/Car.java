package com.example.streams;

import java.util.Objects;

public class Car {

	int vin;
	String name;
	int rank;

	public Car(int vin, String name, int rank) {
		this.vin = vin;
		this.name = name;
		this.rank = rank;
	}

	public int getVin() {
		return vin;
	}

	public void setVin(int vin) {
		this.vin = vin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(name, rank, vin);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		return Objects.equals(name, other.name) && rank == other.rank && vin == other.vin;
	}

	@Override
	public String toString() {
		return "Car [vin=" + vin + ", name=" + name + ", rank=" + rank + "]";
	}

}
