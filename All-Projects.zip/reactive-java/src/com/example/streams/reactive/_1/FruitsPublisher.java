package com.example.streams.reactive._1;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.SubmissionPublisher;

public class FruitsPublisher {

	public static void main(String[] args) throws Exception {

		List<String> inMemoryDB = Arrays.asList("Apple", "Guava", "Banana", "Litchi", "Mango", "Berry", "Cherry", "Green Apple",
				"Tomato","Onion","Palak","Beans","Potato","Cauliflawer","Chillies","Tomato","Onion","Palak","Beans","Potato","Cauliflawer","Chillies","Tomato","Onion","Palak","Beans","Potato","Cauliflawer","Chillies");

		FruitsSubscriber fruitsSubscriberA = new FruitsSubscriber();
		FruitsSubscriber fruitsSubscriberB = new FruitsSubscriber();
		
		//Reactive Publisher
		//SubmissionPublisher<String> publisher = new SubmissionPublisher<>();
		
		ExecutorService executorService = Executors.newFixedThreadPool(2);
		
		//Subscriber with custom worker pool to manage each subscriber buffer and message passing 
		//Good and efficient per subscriber buffer size
		SubmissionPublisher<String> publisher = new SubmissionPublisher<>(executorService,6);
		
		//Resistered Subscribers with publisher
		publisher.subscribe(fruitsSubscriberA); //Non-blocking call
		publisher.subscribe(fruitsSubscriberB); //Non-blocking call
		
		System.out.printf("Total registered Subscribers : %s%n",publisher.getNumberOfSubscribers());
		System.out.printf("Max Buffer size for each Subscriber : %s%n",publisher.getMaxBufferCapacity());
		
		for(String fruitItem : inMemoryDB) {
			//Non-blocking call
			publisher.submit(fruitItem); //Publish the item to registered consumers/subscribers
		}

		//Lets give time for publisher to publish all the items
		Thread.sleep(1000 * 60);
		
		System.out.println("FruitsPublisher published all data and now shutting down!!!!");
		publisher.close(); //Sending a complete signal to all subscribers
		executorService.shutdownNow();

		//Lets give time for publisher to send completion signal
		Thread.sleep(2000);
	}

}
