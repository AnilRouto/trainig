package com.example.streams.reactive._1;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

//Reactive Subscriber
public class FruitsSubscriber implements Subscriber<String> {

	//Subscription Event
	//Data Event
	//Error Event
	//Finish Event
	
	Subscription subscription;
	
	@Override
	public void onSubscribe(Subscription subscription) {
		System.out.println("FruitsSubscriber subscribed successfully!!");
		this.subscription = subscription;
		this.subscription.request(1); //Raise a demand to publisher for n items initially
	}
	
	@Override
	public void onNext(String item) {
		System.out.printf("Current Received Item : %s%n",item);
		//Simulate slow subscriber
		try {
			TimeUnit.MILLISECONDS.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		this.subscription.request(1);
	}
	
	@Override
	public void onError(Throwable throwable) {
		System.out.println("FruitsSubscriber received error signal!!!");
		throwable.printStackTrace();
	}
	
	@Override
	public void onComplete() {
		System.out.println("FruitsSubscriber received completing signal and quiting garcefully!!!");
	}
	
}
