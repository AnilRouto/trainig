package com.example.streams.reactive._2;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

//Reactive Subscriber
public class FruitsSubscriber implements Subscriber<String> {

	// Subscription Event
	// Data Event
	// Error Event
	// Finish Event

	Subscription subscription;
	int totalItemsConsumed = 0;
	String subscriberName;
	long restTime = 0;

	public FruitsSubscriber(String subscriberName,long restTime) {
		this.subscriberName = subscriberName;
		this.restTime = restTime;
	}

	@Override
	public void onSubscribe(Subscription subscription) {
		System.out.printf("%s ==============> FruitsSubscriber subscribed successfully!!%n",subscriberName);
		this.subscription = subscription;
		this.subscription.request(1); // Raise a demand to publisher for n items initially
	}

	@Override
	public void onNext(String item) {
		totalItemsConsumed++;
		System.out.printf("%s ==============> Received Item : %s%n", subscriberName, item);
		// Simulate slow subscriber
		try {
			TimeUnit.MILLISECONDS.sleep(restTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		this.subscription.request(1);
	}

	@Override
	public void onError(Throwable throwable) {
		System.out.printf("%s ==============> FruitsSubscriber received error signal!!!%n",subscriberName);
		System.out.println(throwable.getMessage());
	}

	@Override
	public void onComplete() {
		System.out.printf("%s ==============> FruitsSubscriber processed total '%s' items!!!%n",subscriberName, totalItemsConsumed);
		System.out.println("FruitsSubscriber received completing signal and quiting garcefully!!!");
	}

	public int getTotalItemsConsumed() {
		return totalItemsConsumed;
	}

	public String getSubscriberName() {
		return subscriberName;
	}

}
