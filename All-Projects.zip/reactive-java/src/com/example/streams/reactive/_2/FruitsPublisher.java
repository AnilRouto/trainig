package com.example.streams.reactive._2;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.SubmissionPublisher;
import java.util.concurrent.TimeUnit;

public class FruitsPublisher {

	public static void main(String[] args) throws Exception {
		
		List<String> inMemoryDB = Arrays.asList("Apple", "Guava", "Banana", "Litchi", "Mango", "Berry", "Cherry", "Green Apple",
				"Tomato","Onion","Palak","Beans","Potato","Cauliflawer","Chillies","Tomato","Onion","Palak","Beans","Potato","Cauliflawer","Chillies","Tomato","Onion","Palak","Beans","Potato","Cauliflawer","Chillies");

		FruitsSubscriber mohan = new FruitsSubscriber("Mohan",1000L);
		FruitsSubscriber sohan = new FruitsSubscriber("Sohan",4000L);
		
		ExecutorService executorService = Executors.newFixedThreadPool(2);
		
		//Subscriber with custom worker pool to manage each subscriber buffer and message passing 
		//Good and efficient per subscriber buffer size
		SubmissionPublisher<String> publisher = new SubmissionPublisher<>(executorService,10);
		
		//Resistered Subscribers with publisher
		publisher.subscribe(mohan); //Non-blocking call
		publisher.subscribe(sohan); //Non-blocking call
		
		System.out.printf("Total registered Subscribers : %s%n",publisher.getNumberOfSubscribers());
		System.out.printf("Max Buffer size for each Subscriber : %s%n",publisher.getMaxBufferCapacity());
		
		for(String fruitItem : inMemoryDB) {
			//Non-blocking call
			//Offer items to registered consumers/subscribers
			int dropCount = publisher.offer(fruitItem,1200,TimeUnit.MILLISECONDS,(subscriber,itemDropped) ->{
				String name = ((FruitsSubscriber)subscriber).getSubscriberName();
				Exception exception = new Exception("Mr "+name+", You are slow and buffer is also exhausted so following message you will never get : "+itemDropped);
				subscriber.onError(exception);
				return false; //Do not retry publishing dropped items to that slowest consumer out of all
			});
			
			if(dropCount < 0) {
				System.out.printf("Currently dropping %s item!!%n",-dropCount);
			} else {
				System.out.printf("Subscriber still have %s items in buffer to read and process!!%n",dropCount);
			}
		}

		//Lets give time for publisher to publish all the items
		while(publisher.estimateMaximumLag() > 0) {
			Thread.sleep(200);
		}
			
		/*while(mohan.getTotalItemsConsumed() != inMemoryDB.size()) {
			Thread.sleep(500);
		}*/
		
		
		System.out.println("FruitsPublisher published all data and now shutting down!!!!");
		publisher.close(); //Sending a complete signal to all subscribers
		executorService.shutdownNow();

		//Lets give time for publisher to send completion signal
		Thread.sleep(2000);
	}

}
