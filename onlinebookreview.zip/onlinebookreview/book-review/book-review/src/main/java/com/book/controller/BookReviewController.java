package com.book.controller;

import java.util.List;

import com.book.model.Review;
import com.book.repository.BookReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;






@RestController
//@RequestMapping("/bookreview")
public class BookReviewController {
	@Autowired
	BookReviewRepository bookReviewRepository;
	
	
	
	
	@GetMapping(value = "/api/review")
	public List<Review> getRev() {
		return bookReviewRepository.findAll();
	}
	@GetMapping("/api/review/{id}")
	public List<Review> getReview(@PathVariable String id)
	{
		return bookReviewRepository.findByBookId(id);
		
	}
	
	
	
	 

}
