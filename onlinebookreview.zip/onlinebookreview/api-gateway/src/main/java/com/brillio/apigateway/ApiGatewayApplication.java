package com.brillio.apigateway;


import io.netty.resolver.DefaultAddressResolverGroup;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.netty.http.client.HttpClient;

@SpringBootApplication

//@RefreshScope
//@Configuration

@EnableEurekaClient
@EnableDiscoveryClient
public class ApiGatewayApplication {

	public static void main(String[] args) {
		//HttpClient.create().resolver(DefaultAddressResolverGroup.INSTANCE);



		SpringApplication.run(ApiGatewayApplication.class, args);
	}

	@Bean
	public HttpClient httpClient() {
		return HttpClient.create().resolver(DefaultAddressResolverGroup.INSTANCE);
	}


	/*public PreFilter preFilter() {
		return new PreFilter();
	}

	//	@Bean
	public PostFilter postFilter() {
		return new PostFilter();
	}

	//	@Bean
	public RouteFilter routeFilter() {
		return new RouteFilter();
	}

	//	@Bean
	public ErrorFilter errorFilter() {
		return new ErrorFilter();
	}
*/
}
