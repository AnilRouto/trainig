package com.brillio.aggregateservice.aggregateservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AggregateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
