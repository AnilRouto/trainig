package com.brillio.bookdetailservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookdetailserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
