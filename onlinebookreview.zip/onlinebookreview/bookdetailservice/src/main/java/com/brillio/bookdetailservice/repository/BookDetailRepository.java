package com.brillio.bookdetailservice.repository;

import com.brillio.bookdetailservice.model.BookDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookDetailRepository extends JpaRepository<BookDetail,String> {
}
