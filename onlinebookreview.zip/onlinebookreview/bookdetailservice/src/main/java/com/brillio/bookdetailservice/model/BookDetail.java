package com.brillio.bookdetailservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t_bk_dtl")
public class BookDetail {

    @Id
    private String bookId;
    @Column
    private String name;
    @Column
    private String author;
    @Column
    private String genre;

    public BookDetail() {
    }

    public BookDetail(String bookId, String name, String author, String genre) {
        this.bookId = bookId;
        this.name = name;
        this.author = author;
        this.genre = genre;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
}
