import React, { Component } from "react";
import { Link } from "react-router-dom";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import ViewBooks from "./ViewBooks";
import ViewReviews from "./ViewReviews";




class Nav extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: "",
    };
  }

  // getBooks = (data) => {
  //   this.setState({
  //     data: data,
  //   });
  // };

  render() {
    return (
      <Router>
        <nav
          className="d-flex justify-content-around align-items-center h-100 text-light"
          style={{
            background: "linear-gradient(to right, #0f0c29, #302b63, #24243e)",
          }}
        >
          <Link
            to="/home"
            className="text-uppercase text-light"
            style={{ textDecoration: "none" }}
          >
            <h3>Home</h3>
          </Link>
          <ul className="h-100 w-50 d-flex justify-content-around p-1 list-unstyled">
            <Link to="/add" className="btn btn-outline-info mt-3">
              Add Books
            </Link>
            <Link to="/view" className="btn btn-outline-info mt-3">
              View Books
            </Link>
            <Link to="/viewReview" className="btn btn-outline-info mt-3">
              View Reviews
            </Link>
          </ul>
        </nav>
        <Switch>
          {/* <Route path="/add" exact>
            <Nav getExpense={this.getExpense} />
          </Route> */}
          <Route path="/view" exact>
            <ViewBooks/>
          </Route>
          <Route path="/viewReview" exact>
            <ViewReviews/>
          </Route>
        </Switch>
      </Router>
    );
  }
}

export default Nav;
