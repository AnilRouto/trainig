import React from 'react'
import axios from 'axios'
import { useEffect, useState } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.css";
import "react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";

var api = axios.create({
   // baseURL : "http://localhost:8765/aggregator-service/reviews"
})

function ViewReviews() {

    const [mounted, setMounted] = useState(false);

    // const [books, setBooks] = useState({
    //     bookId: "",
    //     author: "",
    //     ganre: "",
    //     name: "",
    //   });
    const [reviews, setReviews] = useState([]);

    // if(!mounted){
    //     // Code for componentWillMount here
    //     // This code is called only one time before intial render
    //     let res =  axios.get("http://localhost:8765/aggregator-service/books");
    // console.log(res.data);


    //   }

      useEffect(async() =>{

        let res =  await axios.get("http://localhost:8765/aggregator-service/reviews");
        console.log(res.data);
        setReviews(res.data);
        console.log(reviews);
        setMounted(true)
      },[]);

      const columns = [
        { dataField: 'id', text: 'Reting ID', sort: true },
        { dataField: "rating", text: "Rating", sort: true },
        { dataField: "description", text: "Description", sort: true },
        { dataField: "bookId", text: "Book ID", sort: true },
      ];
    
      const defaultSorted = [
        {
          dataField: "id",
          order: "asc",
        },
      ];

      const pagination = paginationFactory({
        page: 1,
        sizePerPage: 5,
        lastPageText: ">>",
        firstPageText: "<<",
        nextPageText: ">",
        prePageText: "<",
        showTotal: true,
        alwaysShowAllBtns: true,
        onPageChange: function (page, sizePerPage) {
          console.log("page", page);
          console.log("sizePerPage", sizePerPage);
        },
        onSizePerPageChange: function (page, sizePerPage) {
          console.log("page", page);
          console.log("sizePerPage", sizePerPage);
        },
      });

      const { SearchBar, ClearSearchButton } = Search;


    return (
        <div
      className="container border text-dark w-50 mt-3 py-5 shadow-lg p-3 mb-5 bg-white rounded"
      style={{ background: "linear-gradient(to right, #d3cce3, #e9e4f0)" }}
    >
      <h5>Find Reviews For all Books Below</h5>

      <ToolkitProvider
        bootstrap4
        keyField="id"
        data={reviews}
        columns={columns}
        search
      >
        {(prop) => (
          <div>
            <h6>Input something at below input field:</h6>
            <SearchBar {...prop.searchProps} />
            <ClearSearchButton {...prop.searchProps} />
            <hr />
            <BootstrapTable
              defaultSorted={defaultSorted}
              pagination={pagination}
              {...prop.baseProps}
            />
          </div>
        )}
      </ToolkitProvider>

      
    </div>
    )
}

export default ViewReviews
