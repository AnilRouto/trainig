import React from 'react'
import axios from 'axios'
import { useEffect, useState } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.css";
import "react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";

var api = axios.create({
   // baseURL : "http://localhost:8081/school"
})

function ViewBooks() {

    const [mounted, setMounted] = useState(false);

    // const [books, setBooks] = useState({
    //     bookId: "",
    //     author: "",
    //     ganre: "",
    //     name: "",
    //   });
    const [books, setBooks] = useState([]);

    // if(!mounted){
    //     // Code for componentWillMount here
    //     // This code is called only one time before intial render
    //     let res =  axios.get("http://localhost:8765/aggregator-service/books");
    // console.log(res.data);


    //   }

      useEffect(async() =>{

        let res =  await axios.get("http://localhost:8765/aggregator-service/books");
        console.log(res.data);
        setBooks(res.data);
        console.log(books);
        setMounted(true)
      },[]);

      const columns = [
        { dataField: 'bookId', text: 'Book ID', sort: true },
        { dataField: "author", text: "Author", sort: true },
        { dataField: "genre", text: "Genre", sort: true },
        { dataField: "name", text: "Name", sort: true },
      ];
    
      const defaultSorted = [
        {
          dataField: "bookId",
          order: "asc",
        },
      ];

      const pagination = paginationFactory({
        page: 1,
        sizePerPage: 4,
        lastPageText: ">>",
        firstPageText: "<<",
        nextPageText: ">",
        prePageText: "<",
        showTotal: true,
        alwaysShowAllBtns: true,
        onPageChange: function (page, sizePerPage) {
          console.log("page", page);
          console.log("sizePerPage", sizePerPage);
        },
        onSizePerPageChange: function (page, sizePerPage) {
          console.log("page", page);
          console.log("sizePerPage", sizePerPage);
        },
      });

      const { SearchBar, ClearSearchButton } = Search;


    return (
        <div
      className="container border text-dark w-50 mt-3 py-5 shadow-lg p-3 mb-5 bg-white rounded"
      style={{ background: "linear-gradient(to right, #d3cce3, #e9e4f0)" }}
    >
      <h5>Find Book Details Below</h5>

      <ToolkitProvider
        bootstrap4
        keyField="bookId"
        data={books}
        columns={columns}
        search
      >
        {(prop) => (
          <div>
            <h6>Input something at below input field:</h6>
            <SearchBar {...prop.searchProps} />
            <ClearSearchButton {...prop.searchProps} />
            <hr />
            <BootstrapTable
              defaultSorted={defaultSorted}
              pagination={pagination}
              {...prop.baseProps}
            />
          </div>
        )}
      </ToolkitProvider>

      {/* {props.expenses.length > 0 &&
        props.expenses[0].map((e, i) => {
          return <h1 key={i}>{e.expenseType}</h1>;
        })} */}
    </div>
    )
}

export default ViewBooks
