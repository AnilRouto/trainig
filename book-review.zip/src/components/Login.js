import React, { Component } from "react";
import { Link, Redirect } from "react-router-dom";


export class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isLogged: false,
      loginParams: {
        username: "",
        password: "",
      },
    };
  }

  handleForm = (event) => {
    let loginParamsNew = { ...this.state.loginParams };
    let val = event.target.value;
    loginParamsNew[event.target.name] = val;
    this.setState({
      loginParams: loginParamsNew,
    });
    // this.setState({...loginParams, [event.target.name]:event.target.value})
  };

  login = (event) => {
    let userName = this.state.loginParams.username;
    let password = this.state.loginParams.password;
    if (userName === "admin" && password === "123") {
      // localStorage.setItem("token", "T");
      this.setState({
        isLogged: true,
      });
    }

    event.preventDefault();
  };

  render() {
    if (this.state.isLogged) {
      return <Redirect to="/Nav" />;
    }
    return (
      <div
        className="container border border-info w-50 p-5 mt-5 text-light shadow-lg p-3 mb-5 bg-white rounded"
        style={{
          background: "linear-gradient(to right, #0f2027, #203a43, #2c5364)",
        }}
      >
        <h1 className="text-center">Login</h1>
        <form className="my-2">
          <div className="form-group row align-items-center">
            <label htmlFor="email" className="col-sm-5">
              User Name:
            </label>
            <input
              type="text"
              id="email"
              className="form-control w-50 my-2 col-sm-6"
              placeholder="abc@gmail.com"
              name="username"
              required
              onChange={this.handleForm}
            />
          </div>
          <div className="form-group row align-items-center">
            <label htmlFor="password" className="col-sm-5">
              {" "}
              Password:
            </label>
            <input
              type="password"
              id="password"
              className="form-control w-50 my-2 col-sm-6"
              placeholder="Abcd9\#"
              name="password"
              required
              onChange={this.handleForm}
            />
          </div>

          <div className="text-center row">
            <div className="col-sm-5"></div>
            <button
              className="btn btn-outline-info my-4 col-sm-6"
              type="submit"
              onClick={this.login}
            >
              Login
            </button>
            {/* <Link to="/home" className="btn btn-outline-info my-4">
            Login
          </Link> */}
          </div>
        </form>
      </div>
    );
  }
}

export default Login;
