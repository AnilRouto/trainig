import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Login from './components/Login';
import Home from './components/Home';
import Nav from './components/Nav';
function App() {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route path="/" exact component={Login} />
          <Route path="/Nav" exact component={Nav} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
